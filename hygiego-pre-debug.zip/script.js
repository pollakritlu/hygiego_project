/* ======================================================
   1. CONFIGURATION & CLIENT INIT
   ====================================================== */
if (typeof window._HYGIE_URL === 'undefined') {
    window._HYGIE_URL = 'https://tfnvgsjfegrpsyuzthpn.supabase.co';
    window._HYGIE_KEY = 'sb_publishable_W6IMM3hM_0UK69ZMgaRrfA_PWJfL9j8';
    window._client = window.supabase.createClient(window._HYGIE_URL, window._HYGIE_KEY);
}

const db = {
    currentUser: null,
    currentRole: null,

init: async function () {
        console.log("HygieGo System Initializing...");
        const storedUser = localStorage.getItem('hygieUser');
        const storedRole = localStorage.getItem('hygieRole');

        if (storedUser) {
            this.currentUser = JSON.parse(storedUser);
            this.currentRole = storedRole;
            this.updateNav();
        }

        // --- Logic ป้องกันการเข้า Dashboard ---
        if (window.location.pathname.includes("dashboard.html")) {
            if (!this.currentUser) {
                // ไม่ได้ล็อกอิน -> ไปหน้าแรก
                window.location.href = 'index.html';
            } else if (this.currentRole === 'user' && this.currentUser.payment_status !== 'paid') {
                // ล็อกอินแล้ว แต่ยังไม่จ่ายเงิน -> ไปหน้าซื้อแพ็คเกจ
                alert("⚠️ กรุณาเลือกซื้อแพ็คเกจก่อนเข้าใช้งานระบบ");
                window.location.href = 'pricing.html';
            } else {
                // ผ่านทุกด่าน -> โหลด Dashboard
                await this.renderDashboard();
            }
        }
    },

    /* ======================================================
       2. AUTHENTICATION (LOGIN & REGISTER)
       ====================================================== */
    login: async function (email, password) {
        console.log("Attempting login for:", email);
        try {
            // 1. เช็ค Users
            let { data: user } = await window._client.from('Users').select('*').eq('email', email).single();
            if (user) {
                if (user.password_hash === password) {
                    this.saveSession(user, 'user');
                    return;
                }
            }

            // 2. เช็ค Admin
            let { data: admin } = await window._client.from('Admin').select('*').eq('email', email).single();
            if (admin) {
                if (admin.password_hash === password) {
                    this.saveSession(admin, 'admin');
                    return;
                }
            }

            alert("❌ อีเมลหรือรหัสผ่านไม่ถูกต้อง");
        } catch (err) {
            console.error("Login Error:", err);
            alert("เกิดข้อผิดพลาดในการเชื่อมต่อระบบ");
        }
    },

    register: async function (userData) {
        try {
            const btn = document.getElementById("auth-btn-submit");
            if (btn) {
                btn.innerText = "กำลังบันทึก...";
                btn.disabled = true;
            }

            // Insert ลง Supabase
            const { data, error } = await window._client
                .from('Users')
                .insert([userData])
                .select();

            if (error) {
                console.error("Register Error:", error);
                if (error.message.includes("duplicate")) {
                    alert("❌ อีเมลนี้ถูกใช้งานแล้ว");
                } else {
                    alert("เกิดข้อผิดพลาด: " + error.message);
                }
                return;
            }

            alert("✅ สมัครสมาชิกสำเร็จ! ยินดีต้อนรับสู่ครอบครัว HygieGo");
            
            // Auto Login หลังสมัครเสร็จ
            await this.login(userData.email, userData.password_hash);

        } catch (err) {
            console.error("System Error:", err);
            alert("เกิดข้อผิดพลาดที่ไม่คาดคิด");
        } finally {
            const btn = document.getElementById("auth-btn-submit");
            if (btn) {
                btn.innerText = "ลงทะเบียน";
                btn.disabled = false;
            }
        }
    },

    saveSession: function (data, role) {
        this.currentUser = data;
        this.currentRole = role;
        localStorage.setItem('hygieUser', JSON.stringify(data));
        localStorage.setItem('hygieRole', role);

        // 1. เช็คว่ามีลิงก์จ่ายเงินค้างไว้ไหม (กรณีเลือกแพ็คเกจมาก่อน Login)
        const pendingUrl = localStorage.getItem('pendingPaymentUrl');
        if (pendingUrl && role === 'user') {
            localStorage.removeItem('pendingPaymentUrl');
            window.location.href = pendingUrl;
            return;
        }

        // 2. เช็คว่าเป็น Admin หรือไม่ (Admin เข้าได้เลย)
        if (role === 'admin') {
            window.location.href = "dashboard.html";
            return;
        }

        // 3. เช็คสถานะการจ่ายเงิน (สำหรับ User ทั่วไป)
        if (data.payment_status === 'paid') {
            window.location.href = "dashboard.html";
        } else {
            // ถ้ายังไม่จ่าย พาไปเลือกแพ็คเกจ
            window.location.href = "pricing.html";
        }
    },

    logout: function () {
        localStorage.clear();
        window.location.href = "index.html";
    },

    updateNav: function () {
        const navAuth = document.getElementById("nav-auth-section");
        if (!navAuth) return;

        if (this.currentUser) {
            const name = this.currentRole === 'user' ? this.currentUser.restaurant_name : this.currentUser.first_name;
            navAuth.innerHTML = `
                <div class="user-nav-group">
                    <a href="dashboard.html" class="btn-nav-dash" title="ไปที่หน้าจัดการ">
                        <i class="fas fa-chart-line"></i> <span>Dashboard</span>
                    </a>
                    <div class="user-profile-display">
                        <span class="user-text">${name}</span>
                    </div>
                    <button onclick="db.logout()" class="btn-nav-logout" title="ออกจากระบบ">
                        <i class="fas fa-power-off"></i>
                    </button>
                </div>
            `;
        } else {
            navAuth.innerHTML = `<button class="btn-login" onclick="openModal('auth-modal')">เข้าสู่ระบบ</button>`;
        }
    },

    renderDashboard: async function () {
        const user = this.currentUser;
        const uName = document.getElementById("u-name");
        if (uName) uName.textContent = this.currentRole === 'user' ? user.restaurant_name : user.first_name;
        
        const rBadge = document.getElementById("role-badge");
        if (rBadge) rBadge.textContent = this.currentRole.toUpperCase();

        if (this.currentRole === 'admin') {
            document.getElementById("menu-admin")?.classList.remove('hidden');
            window.showView('view-admin');
            await this.renderAdminTable();
        } else {
            document.getElementById("menu-customer")?.classList.remove('hidden');
            window.showView('view-customer');
            await this.renderCustomerStats();
        }
    },

    // --- ส่วนของ Admin ---
    renderAdminTable: async function () {
        const { data: list, error } = await window._client
            .from('Inspection')
            .select(`*, Booking ( Packagetransaction ( Users ( restaurant_name ) ) )`)
            .order('created_at', { ascending: false });

        if (error) { console.error("Admin Fetch Error:", error); return; }

        const tbody = document.getElementById("admin-task-table");
        if (tbody && list) {
            document.getElementById("stat-total").textContent = list.length;
            document.getElementById("stat-done").textContent = list.filter(i => i.status === 'completed').length;
            document.getElementById("stat-doing").textContent = list.filter(i => i.status !== 'completed').length;

            tbody.innerHTML = list.map(i => {
                const restaurantName = i.Booking?.Packagetransaction?.Users?.restaurant_name || 'ไม่ระบุร้านค้า';
                const hasImage = i.image_url ? '<i class="fas fa-image" style="color:#00C3AA;" title="มีรูปภาพแนบ"></i>' : '';
                return `
                <tr>
                    <td><strong>${restaurantName}</strong> ${hasImage}<br><small style="color:#888;">ID: ${i.inspection_id}</small></td>
                    <td><span class="badge ${i.status === 'completed' ? 'status-done' : 'status-doing'}">${i.status}</span></td>
                    <td>${i.inspection_date || 'รอระบุ'}</td>
                    <td style="text-align:right;"><button class="action-btn" onclick="window.openTaskModal('${i.inspection_id}')"><i class="fas fa-edit"></i></button></td>
                </tr>
            `}).join('');
        }
    },

    // --- ส่วนของ User (Customer) ---
    renderCustomerStats: async function () {
        document.getElementById("user-name-display").textContent = this.currentUser.restaurant_name;
        
        try {
            const { data: tx } = await window._client.from('Packagetransaction')
                .select('*, Packages(package_name)').eq('user_id', this.currentUser.user_id)
                .order('created_at', { ascending: false }).limit(1).single();
            if (tx) document.getElementById("active-package").textContent = tx.Packages?.package_name || "Smart Plan";
        } catch(e) {}

        const { data: myTasks } = await window._client.from('Inspection')
            .select(`*, Booking!inner ( Packagetransaction!inner ( user_id ) )`)
            .eq('Booking.Packagetransaction.user_id', this.currentUser.user_id)
            .order('created_at', { ascending: false });

        const docList = document.getElementById("document-list");
        if (docList && myTasks && myTasks.length > 0) {
            document.getElementById("no-doc-placeholder")?.classList.add("hidden");
            docList.innerHTML = `<h3 style="margin-bottom:15px;">รายการตรวจของคุณ</h3>` + myTasks.map(task => `
                <div style="background:white; padding:15px; border-radius:8px; margin-bottom:10px; border:1px solid #eee; display:flex; justify-content:space-between; align-items:center;">
                    <div>
                        <div style="font-weight:bold;">วันที่นัดหมาย: ${task.inspection_date || 'รอเจ้าหน้าที่ระบุ'}</div>
                        <div style="font-size:12px; color:#666;">สถานะ: ${task.status}</div>
                        ${task.image_url ? '<div style="font-size:12px; color:#00C3AA;"><i class="fas fa-check-circle"></i> ส่งรูปแล้ว</div>' : ''}
                    </div>
                    <div>
                        ${task.image_url ? `<button onclick="window.openFullImage('${task.image_url}')" style="margin-right:5px; cursor:pointer; background:none; border:none; color:#00C3AA;">ดูรูป</button>` : ''}
                        <button onclick="window.triggerUpload('${task.inspection_id}')" style="background:${task.image_url ? '#f0f0f0' : '#00C3AA'}; color:${task.image_url ? '#333' : 'white'}; border:none; padding:8px 15px; border-radius:5px; cursor:pointer;">
                            <i class="fas fa-camera"></i> ${task.image_url ? 'เปลี่ยนรูป' : 'แนบรูป'}
                        </button>
                    </div>
                </div>
            `).join('');
        }
    }
};

/* ======================================================
   3. HELPER FUNCTIONS (Upload, Payment, Modal)
   ====================================================== */
let currentUploadTaskId = null;
window.triggerUpload = (taskId) => {
    currentUploadTaskId = taskId;
    let uploader = document.getElementById('hidden-uploader');
    if (!uploader) {
        uploader = document.createElement('input');
        uploader.type = 'file';
        uploader.id = 'hidden-uploader';
        uploader.style.display = 'none';
        uploader.accept = 'image/*';
        uploader.onchange = window.handleImageUpload;
        document.body.appendChild(uploader);
    }
    uploader.click();
};

window.handleImageUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { alert("กรุณาเลือกไฟล์รูปภาพเท่านั้น"); return; }

    try {
        if (!confirm("ยืนยันการส่งรูปภาพนี้?")) return;
        const fileName = `${Date.now()}_${file.name.replace(/\s/g, '')}`;
        const { error: uploadError } = await window._client.storage.from('task-images').upload(fileName, file);
        if (uploadError) throw uploadError;
        
        const { data: { publicUrl } } = window._client.storage.from('task-images').getPublicUrl(fileName);
        const { error: dbError } = await window._client.from('Inspection').update({ image_url: publicUrl }).eq('inspection_id', currentUploadTaskId);
        if (dbError) throw dbError;

        alert("อัปโหลดเรียบร้อย! ✅");
        db.renderDashboard(); 
    } catch (err) {
        console.error("Upload Failed:", err);
        alert("เกิดข้อผิดพลาด: " + err.message);
    } finally { event.target.value = ''; }
};

window.openFullImage = (src) => {
    const modal = document.getElementById('image-modal');
    const img = document.getElementById('full-image-preview');
    if(modal && img) { img.src = src; modal.classList.remove('hidden'); } 
    else { window.open(src, '_blank'); }
};

window.saveTask = async function() {
    const id = document.getElementById("task-id").value;
    const status = document.getElementById("task-status").value;
    const date = document.getElementById("task-due").value;
    try {
        await window._client.from('Inspection').update({ status: status, inspection_date: date }).eq('inspection_id', id);
        alert("บันทึกข้อมูลเรียบร้อย ✅");
        window.closeModal('task-modal');
        await db.renderAdminTable();
    } catch (e) { console.error(e); alert("เกิดข้อผิดพลาด"); }
};

window.openTaskModal = async (id = null) => {
    window.openModal('task-modal');
    document.getElementById("task-id").value = id || "";
    const imgEl = document.getElementById("admin-task-img");
    const placeholder = document.getElementById("img-placeholder");
    
    if(imgEl) imgEl.classList.add("hidden");
    if(placeholder) { placeholder.classList.remove("hidden"); placeholder.innerText = "กำลังโหลดข้อมูล..."; }

    if (id) {
        let { data: task } = await window._client.from('Inspection').select('*').eq('inspection_id', id).single();
        if (task) {
            document.getElementById("task-status").value = task.status;
            document.getElementById("task-due").value = task.inspection_date;
            if (task.image_url) {
                if(imgEl) { imgEl.src = task.image_url; imgEl.classList.remove("hidden"); }
                if(placeholder) placeholder.classList.add("hidden");
            } else {
                if(placeholder) placeholder.innerText = "ร้านค้านี้ยังไม่ได้แนบรูปภาพ";
            }
        }
    }
};

window.submitInspectionRequest = async function() {
    if (!db.currentUser || !db.currentUser.user_id) { alert("กรุณาเข้าสู่ระบบใหม่เพื่อดำเนินการ"); return; }
    try {
        const btn = event.target;
        const originalText = btn.innerHTML;
        btn.disabled = true;
        btn.innerText = "กำลังบันทึก...";

        const { data: latestTask } = await window._client.from('Inspection')
            .select(`inspection_id, status, Booking!inner ( Packagetransaction!inner ( user_id ) )`)
            .eq('Booking.Packagetransaction.user_id', db.currentUser.user_id)
            .neq('status', 'completed').order('created_at', { ascending: false }).limit(1).single();

        if (!latestTask) { alert("ไม่พบรายการตรวจที่ต้องการบันทึก"); btn.disabled = false; btn.innerText = originalText; return; }

        await window._client.from('Inspection').update({ status: 'pending', updated_at: new Date().toISOString() }).eq('inspection_id', latestTask.inspection_id);
        alert("บันทึกและส่งคำขอตรวจเรียบร้อยแล้ว! ✅");
        await db.renderCustomerStats();
    } catch (err) {
        console.error("Submit Error:", err);
        alert("เกิดข้อผิดพลาดในการบันทึก");
    } finally {
        const btn = document.querySelector('button[onclick*="submitInspectionRequest"]');
        if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-save"></i> บันทึกและส่งคำขอตรวจ'; }
    }
};

window.handlePackageSelection = function(planName, price) {
    const user = localStorage.getItem('hygieUser');
    if (user) {
        window.location.href = `payment.html?plan=${planName}&price=${price}`;
    } else {
        localStorage.setItem('pendingPaymentUrl', `payment.html?plan=${planName}&price=${price}`);
        alert("กรุณาเข้าสู่ระบบเพื่อดำเนินการชำระเงิน");
        window.openModal('auth-modal');
    }
};

/* ======================================================
   4. MODAL & AUTH UI LOGIC (แก้ไขใหม่)
   ====================================================== */
let isRegisterMode = false;

window.toggleAuthMode = () => {
    isRegisterMode = !isRegisterMode;
    const title = document.getElementById("auth-title");
    const btn = document.getElementById("auth-btn-submit");
    const regFields = document.getElementById("register-fields");
    const toggleText = document.getElementById("auth-toggle-text");
    const toggleLink = document.getElementById("auth-toggle-link");

    // Safety Check: ถ้า HTML ยังเป็นตัวเก่า (ไม่มี register-fields) จะไม่ Error
    if (!regFields) {
        console.warn("Register fields missing in HTML");
        return;
    }

    if (isRegisterMode) {
        title.innerText = "สมัครสมาชิกใหม่";
        btn.innerText = "ลงทะเบียน";
        btn.style.background = "#2563eb"; 
        regFields.classList.remove("hidden");
        toggleText.innerText = "มีบัญชีอยู่แล้ว?";
        toggleLink.innerText = "เข้าสู่ระบบ";
    } else {
        title.innerText = "เข้าสู่ระบบ";
        btn.innerText = "เข้าสู่ระบบ";
        btn.style.background = "#00C3AA"; 
        regFields.classList.add("hidden");
        toggleText.innerText = "ยังไม่มีบัญชี?";
        toggleLink.innerText = "สมัครสมาชิก";
    }
};

window.handleAuthSubmit = async (e) => {
    e.preventDefault();
    
    // ดึงค่าพื้นฐาน
    const emailEl = document.getElementById("auth-email");
    const passEl = document.getElementById("auth-pass");

    if (!emailEl || !passEl) {
        // Fallback: เผื่อบางหน้ายังใช้ ID เก่า (auth-user)
        const oldUser = document.getElementById("auth-user");
        if (oldUser && passEl) {
             db.login(oldUser.value, passEl.value);
             return;
        }
        alert("System Error: ไม่พบช่องกรอก Email");
        return;
    }

    const email = emailEl.value.trim();
    const pass = passEl.value.trim();

    if (!email || !pass) {
        alert("กรุณากรอกอีเมลและรหัสผ่าน");
        return;
    }

    if (isRegisterMode) {
        // --- สมัครสมาชิก ---
        const confirmPass = document.getElementById("auth-confirm-pass")?.value.trim();
        if (pass !== confirmPass) { alert("❌ รหัสผ่านไม่ตรงกัน"); return; }

        const formData = {
            email: email,
            password_hash: pass,
            first_name: document.getElementById("reg-fname")?.value || "",
            last_name: document.getElementById("reg-lname")?.value || "",
            phone: document.getElementById("reg-phone")?.value || "",
            restaurant_name: document.getElementById("reg-shop-name")?.value || "",
            restaurant_address: document.getElementById("reg-address")?.value || "",
            subdistrict: document.getElementById("reg-subdistrict")?.value || "",
            district: document.getElementById("reg-district")?.value || "",
            province: document.getElementById("reg-province")?.value || "",
            postal_code: document.getElementById("reg-zip")?.value || "",
            role: 'user',
            status: 'active',
            created_at: new Date().toISOString()
        };

        if (!formData.first_name || !formData.restaurant_name || !formData.phone) {
            alert("❌ กรุณากรอกชื่อจริง, เบอร์โทร และชื่อร้าน");
            return;
        }

        await db.register(formData);

    } else {
        // --- ล็อกอิน ---
        await db.login(email, pass);
    }
};

/* ======================================================
   8. USER PROFILE EDIT SYSTEM
   ====================================================== */

// เปิด Modal และดึงข้อมูลปัจจุบันมาใส่ในช่อง
window.openProfileModal = function() {
    if (!db.currentUser) {
        alert("กรุณาเข้าสู่ระบบใหม่");
        return;
    }

    const user = db.currentUser;

    // เติมข้อมูลลงในช่อง (เช็คว่ามี element ไหมก่อนเติม)
    const setVal = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.value = val || '';
    };

    setVal('edit-email', user.email);
    setVal('edit-fname', user.first_name);
    setVal('edit-lname', user.last_name);
    setVal('edit-phone', user.phone);
    setVal('edit-shop-name', user.restaurant_name);
    setVal('edit-address', user.restaurant_address);
    setVal('edit-subdistrict', user.subdistrict);
    setVal('edit-district', user.district);
    setVal('edit-province', user.province);
    setVal('edit-zip', user.postal_code);

    window.openModal('profile-modal');
};

// บันทึกข้อมูลลง Database
window.saveProfile = async function() {
    const btn = document.querySelector('#profile-modal .btn-full-green');
    const originalText = btn.innerText;
    btn.innerText = "กำลังบันทึก...";
    btn.disabled = true;

    try {
        // 1. เตรียมข้อมูลที่จะอัปเดต
        const updates = {
            first_name: document.getElementById('edit-fname').value,
            last_name: document.getElementById('edit-lname').value,
            phone: document.getElementById('edit-phone').value,
            restaurant_name: document.getElementById('edit-shop-name').value,
            restaurant_address: document.getElementById('edit-address').value,
            subdistrict: document.getElementById('edit-subdistrict').value,
            district: document.getElementById('edit-district').value,
            province: document.getElementById('edit-province').value,
            postal_code: document.getElementById('edit-zip').value,
            updated_at: new Date().toISOString()
        };

        // 2. ส่งไปอัปเดตที่ Supabase (ใช้ user_id เป็นตัวระบุ)
        const { data, error } = await window._client
            .from('Users')
            .update(updates)
            .eq('user_id', db.currentUser.user_id)
            .select()
            .single();

        if (error) throw error;

        // 3. อัปเดตข้อมูลใน LocalStorage และหน้าเว็บทันที
        const newUserData = { ...db.currentUser, ...updates };
        
        // บันทึกลงเครื่องใหม่
        localStorage.setItem('hygieUser', JSON.stringify(newUserData));
        db.currentUser = newUserData; // อัปเดตตัวแปรใน memory

        alert("✅ แก้ไขข้อมูลเรียบร้อยแล้ว!");
        window.closeModal('profile-modal');
        
        // รีเฟรชหน้า Dashboard เพื่อแสดงชื่อใหม่ (ถ้ามีการเปลี่ยนชื่อร้าน)
        await db.renderDashboard();
        // รีเฟรช Navbar
        db.updateNav();

    } catch (err) {
        console.error("Update Failed:", err);
        alert("เกิดข้อผิดพลาดในการบันทึก: " + err.message);
    } finally {
        btn.innerText = originalText;
        btn.disabled = false;
    }
};

/* ======================================================
   9. DELETE ACCOUNT SYSTEM
   ====================================================== */
window.deleteAccount = async function() {
    if (!db.currentUser) return;

    // ยืนยันครั้งที่ 1
    const confirm1 = confirm("❗ คุณแน่ใจหรือไม่ว่าต้องการลบบัญชี?\nข้อมูลทุกอย่างของคุณจะหายไปถาวร!");
    if (!confirm1) return;

    // ยืนยันครั้งที่ 2
    const confirm2 = confirm("⚠️ ยืนยันการลบครั้งสุดท้าย? (ไม่สามารถยกเลิกได้)");
    if (!confirm2) return;

    try {
        const userId = db.currentUser.user_id;

        // ลบจากตาราง Users ใน Supabase
        const { error } = await window._client
            .from('Users')
            .delete()
            .eq('user_id', userId);

        if (error) throw error;

        alert("ลบบัญชีเรียบร้อยแล้ว หวังว่าจะได้พบกันใหม่ครับ");
        
        // เคลียร์ session และกลับหน้าหลัก
        db.logout(); 

    } catch (err) {
        console.error("Delete Error:", err);
        alert("เกิดข้อผิดพลาด: " + err.message);
    }
};

// เพิ่มฟังก์ชันเปิด Modal ให้เรียกใช้ได้จาก Dashboard
window.openProfileModal = function() {
    const user = db.currentUser;
    if (!user) return;

    document.getElementById('edit-email').value = user.email || '';
    document.getElementById('edit-fname').value = user.first_name || '';
    document.getElementById('edit-lname').value = user.last_name || '';
    document.getElementById('edit-shop-name').value = user.restaurant_name || '';
    
    window.openModal('profile-modal');
};

// Global Helpers (ประกาศไว้ตรงนี้ทีเดียว ไม่ทับซ้อน)
window.openModal = (id) => {
    const m = document.getElementById(id);
    if(m) {
        m.classList.remove("hidden");
        if(id === 'auth-modal' && isRegisterMode) toggleAuthMode(); // Reset to login
    }
};
window.closeModal = (id) => document.getElementById(id)?.classList.add("hidden");
window.showView = (id) => { document.querySelectorAll('.view-section').forEach(v => v.classList.add('hidden')); document.getElementById(id)?.classList.remove('hidden'); };

document.addEventListener('DOMContentLoaded', () => db.init());