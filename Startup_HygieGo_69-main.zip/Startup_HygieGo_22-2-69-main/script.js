/* ======================================================
   1. CONFIGURATION & CLIENT INIT
   ====================================================== */
if (typeof window._HYGIE_URL === 'undefined') {
    window._HYGIE_URL = 'https://tfnvgsjfegrpsyuzthpn.supabase.co';
    window._HYGIE_KEY = 'sb_publishable_W6IMM3hM_0UK69ZMgaRrfA_PWJfL9j8';
    window._client = window.supabase.createClient(window._HYGIE_URL, window._HYGIE_KEY);
}

const db = {
    currentUser: null,
    currentRole: null,

    init: async function() {
        console.log("HygieGo System Initializing...");
        const storedUser = localStorage.getItem('hygieUser');
        const storedRole = localStorage.getItem('hygieRole');

        if (storedUser) {
            this.currentUser = JSON.parse(storedUser);
            this.currentRole = storedRole;
            this.updateNav();
        }

        // --- Logic ป้องกันการเข้า Dashboard ---
        if (window.location.pathname.includes("dashboard.html")) {
            if (!this.currentUser) {
                // 1. ไม่ได้ล็อกอิน -> เด้งไปหน้าแรกทันที
                window.location.href = 'index.html';
            } else if (this.currentRole === 'user' && this.currentUser.payment_status !== 'paid') {
                // 2. ล็อกอินแล้วแต่ยังไม่จ่ายเงิน -> แจ้งเตือนสวยๆ ก่อนเด้งไปหน้า Pricing
                Swal.fire({
                    icon: 'warning',
                    title: 'ยังไม่พบการชำระเงิน',
                    text: 'กรุณาเลือกซื้อแพ็คเกจเพื่อเปิดใช้งานระบบจัดการครับ',
                    confirmButtonColor: '#00C3AA',
                    confirmButtonText: 'ดูแพ็คเกจราคา',
                    allowOutsideClick: false
                }).then(() => {
                    window.location.href = 'pricing.html';
                });
            } else {
                // 3. ผ่านทุกเงื่อนไข -> โหลด Dashboard ตามปกติ
                await this.renderDashboard();
            }
        }
    },

    /* ======================================================
       2. AUTHENTICATION (LOGIN & REGISTER)
       ====================================================== */
    login: async function(email, password) {
        console.log("Attempting login for:", email);
        try {
            // 1. เช็ค Users
            let { data: user } = await window._client.from('Users').select('*').eq('email', email).single();
            if (user) {
                if (user.password_hash === password) {
                    this.saveSession(user, 'user');
                    return;
                }
            }

            // 2. เช็ค Admin
            let { data: admin } = await window._client.from('Admin').select('*').eq('email', email).single();
            if (admin) {
                if (admin.password_hash === password) {
                    this.saveSession(admin, 'admin');
                    return;
                }
            }

            Swal.fire({
                icon: 'error',
                title: 'เข้าสู่ระบบไม่สำเร็จ',
                text: 'อีเมลหรือรหัสผ่านไม่ถูกต้อง ❌',
                confirmButtonColor: '#00C3AA'
            });

        } catch (err) {
            console.error("Login Error:", err);
            Swal.fire({
                icon: 'warning',
                title: 'การเชื่อมต่อผิดพลาด',
                text: 'ไม่สามารถติดต่อเซิร์ฟเวอร์ได้ในขณะนี้ กรุณาลองใหม่ครับ',
                confirmButtonColor: '#00C3AA'
            });
        }
    },

    register: async function(userData) {
        try {
            const btn = document.getElementById("auth-btn-submit");
            if (btn) {
                btn.innerText = "กำลังบันทึก...";
                btn.disabled = true;
            }

            // Insert ลง Supabase
            const { data, error } = await window._client
                .from('Users')
                .insert([userData])
                .select();

            if (error) {
                console.error("Register Error:", error);
                if (error.message.includes("duplicate")) {
                    Swal.fire({
                        icon: 'info',
                        title: 'อีเมลนี้มีเจ้าของแล้ว',
                        text: 'ดูเหมือนคุณจะมีบัญชีอยู่แล้ว ลองเข้าสู่ระบบดูไหมครับ?',
                        confirmButtonColor: '#00C3AA'
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'สมัครสมาชิกไม่สำเร็จ',
                        text: 'ข้อผิดพลาด: ' + error.message,
                        confirmButtonColor: '#00C3AA'
                    });
                }
                return;
            }

            await Swal.fire({
                icon: 'success',
                title: 'สมัครสมาชิกสำเร็จ!',
                text: 'ยินดีต้อนรับสู่ครอบครัว HygieGo ✅',
                timer: 2000,
                showConfirmButton: false
            });

            // Auto Login หลังสมัครเสร็จ
            await this.login(userData.email, userData.password_hash);

        } catch (err) {
            console.error("System Error:", err);
            Swal.fire({
                icon: 'warning',
                title: 'ระบบขัดข้อง',
                text: 'เกิดข้อผิดพลาดที่ไม่คาดคิด กรุณาลองใหม่อีกครั้ง',
                confirmButtonColor: '#00C3AA'
            });
        } finally {
            const btn = document.getElementById("auth-btn-submit");
            if (btn) {
                btn.innerText = "ลงทะเบียน";
                btn.disabled = false;
            }
        }
    },

    saveSession: function(data, role) {
        this.currentUser = data;
        this.currentRole = role;
        localStorage.setItem('hygieUser', JSON.stringify(data));
        localStorage.setItem('hygieRole', role);

        // 1. เช็คว่ามีลิงก์จ่ายเงินค้างไว้ไหม (กรณีเลือกแพ็คเกจมาก่อน Login)
        const pendingUrl = localStorage.getItem('pendingPaymentUrl');
        if (pendingUrl && role === 'user') {
            localStorage.removeItem('pendingPaymentUrl');
            window.location.href = pendingUrl;
            return;
        }

        // 2. เช็คว่าเป็น Admin หรือไม่ (Admin เข้าได้เลย)
        if (role === 'admin') {
            window.location.href = "dashboard.html";
            return;
        }

        // 3. เช็คสถานะการจ่ายเงิน (สำหรับ User ทั่วไป)
        if (data.payment_status === 'paid') {
            window.location.href = "dashboard.html";
        } else {
            window.location.href = "pricing.html";
        }
    },

    logout: function() {
        localStorage.clear();
        window.location.href = "index.html";
    },

    updateNav: function() {
        const navAuth = document.getElementById("nav-auth-section");
        if (!navAuth) return;

        if (this.currentUser) {
            const name = this.currentRole === 'user' ? this.currentUser.restaurant_name : this.currentUser.first_name;
            navAuth.innerHTML = `
                <div class="user-nav-group">
                    <a href="dashboard.html" class="btn-nav-dash" title="ไปที่หน้าจัดการ">
                        <i class="fas fa-chart-line"></i> <span>Dashboard</span>
                    </a>
                    <div class="user-profile-display">
                        <span class="user-text">${name}</span>
                    </div>
                    <button onclick="db.logout()" class="btn-nav-logout" title="ออกจากระบบ">
                        <i class="fas fa-power-off"></i>
                    </button>
                </div>
            `;
        } else {
            navAuth.innerHTML = `<button class="btn-login" onclick="openModal('auth-modal')">เข้าสู่ระบบ</button>`;
        }
    },

    renderDashboard: async function() {
        const user = this.currentUser;
        const uName = document.getElementById("u-name");
        if (uName) uName.textContent = this.currentRole === 'user' ? user.restaurant_name : user.first_name;

        const rBadge = document.getElementById("role-badge");
        if (rBadge) rBadge.textContent = this.currentRole.toUpperCase();

        if (this.currentRole === 'admin') {
            const adminMenu = document.getElementById("menu-admin");
            if (adminMenu) adminMenu.classList.remove('hidden');
            window.showView('view-admin');
            await this.renderAdminTable();
        } else {
            const customerMenu = document.getElementById("menu-customer");
            if (customerMenu) customerMenu.classList.remove('hidden');
            window.showView('view-customer');
            await this.renderCustomerStats();
        }
    },

    // --- ส่วนของ Admin ---
    renderAdminTable: async function() {
        // 1. ระบุตำแหน่งตาราง
        const tbody = document.getElementById("admin-task-table");
        if (!tbody) return;

        // 2. ล้างข้อมูลเก่าในตารางทิ้งก่อน เพื่อให้ User เห็นว่าระบบกำลังอัปเดต
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;">🔄 กำลังโหลดข้อมูลล่าสุด...</td></tr>';

        // 3. ดึงข้อมูล (เพิ่ม .select('*') และดึงข้อมูลใหม่จาก Supabase)
        const { data: list, error } = await window._client
            .from('Inspection')
            .select(`*, Booking ( Packagetransaction ( Users ( restaurant_name ) ) )`)
            .order('created_at', { ascending: false });

        if (error) {
            console.error("Admin Fetch Error:", error);
            tbody.innerHTML = '<tr><td colspan="4" style="text-align:center; color:red;">เกิดข้อผิดพลาดในการโหลดข้อมูล</td></tr>';
            return;
        }

        if (list) {
            // --- 📊 ส่วนที่ 1: อัปเดตตัวเลขสถิติ (Stats) ---
            const total = list.length;
            const done = list.filter(i => i.status === 'completed').length;
            const doing = list.filter(i => i.status !== 'completed').length;

            if (document.getElementById("stat-total")) document.getElementById("stat-total").textContent = total;
            if (document.getElementById("stat-done")) document.getElementById("stat-done").textContent = done;
            if (document.getElementById("stat-doing")) document.getElementById("stat-doing").textContent = doing;

            // --- 📋 ส่วนที่ 2: วาดรายการในตารางใหม่ ---
            tbody.innerHTML = list.map(i => {
                let restaurantName = 'ไม่ระบุร้านค้า';

                if (i.restaurant_name) {
                    restaurantName = i.restaurant_name;
                } else if (i.Booking && i.Booking.Packagetransaction && i.Booking.Packagetransaction.Users) {
                    restaurantName = i.Booking.Packagetransaction.Users.restaurant_name || 'ไม่ระบุร้านค้า';
                }

                let hasImage = i.image_url ? '<i class="fas fa-image" style="color:#00C3AA;" title="มีรูปภาพแนบ"></i>' : '';
                const statusClass = i.status === 'completed' ? 'status-done' : 'status-doing';

                return `
                <tr>
                    <td>
                        <strong>${restaurantName}</strong> ${hasImage}
                        <br>
                        <small style="color:#888;">ID: ${i.inspection_id}</small>
                    </td>
                    <td>
                        <span class="badge ${statusClass}">${i.status}</span>
                    </td>
                    <td>${i.inspection_date || '-'}</td>
                    <td style="text-align:right;">
                        <div style="display: flex; gap: 8px; justify-content: flex-end;">
                            <button class="action-btn" onclick="window.openTaskModal('${i.inspection_id}')">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="action-btn" onclick="window.deleteTaskDirect('${i.inspection_id}')" 
                                    style="background-color: #fee2e2; color: #dc2626; border: none; padding: 6px 10px; border-radius: 6px; cursor: pointer;">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `;
            }).join('');
        }
    },

    // --- ส่วนของ User (Customer) ---
    renderCustomerStats: async function() {
        document.getElementById("user-name-display").textContent = this.currentUser.restaurant_name;

        // --- ส่วนดึงข้อมูลแพ็คเกจ ---
        try {
            const { data: tx } = await window._client.from('Packagetransaction')
                .select('*, Packages(package_name)')
                .eq('user_id', this.currentUser.user_id)
                .order('created_at', { ascending: false })
                .limit(1)
                .single();

            if (tx && tx.Packages) {
                const activePkg = document.getElementById("active-package");
                if (activePkg) {
                    activePkg.textContent = tx.Packages.package_name || "Smart Plan";
                }
            }
        } catch (e) {
            console.log("Package check skipped or not found");
        }

        // --- ส่วนดึงรายการงาน (Tasks) ---
        const { data: myTasks, error } = await window._client.from('Inspection')
            .select(`*, Booking!inner ( Packagetransaction!inner ( user_id ) )`)
            .eq('Booking.Packagetransaction.user_id', this.currentUser.user_id)
            .order('created_at', { ascending: false });

        if (error) {
            console.error("Load tasks error:", error);
        }

        // ✅ สำคัญ: อย่าเขียนทับ #document-list เพราะข้างในมี #preview-container สำหรับพรีวิวหลายรูป + ปุ่มลบก่อนส่ง
        const taskList = document.getElementById("task-list");
        const placeholder = document.getElementById("no-doc-placeholder");

        if (!taskList) return;

        if (myTasks && myTasks.length > 0) {
            if (placeholder) {
                placeholder.classList.add("hidden");
            }

            taskList.innerHTML = `<h3 style="margin-bottom:15px;">รายการตรวจของคุณ</h3>` + myTasks.map(task => {
                const inspectionDate = task.inspection_date || 'รอเจ้าหน้าที่ระบุ';
                const hasImgStatus = task.image_url
                    ? '<div style="font-size:12px; color:#00C3AA;"><i class="fas fa-check-circle"></i> ส่งรูปแล้ว</div>'
                    : '<div style="font-size:12px; color:#94a3b8;">ยังไม่ส่งรูป</div>';

                // ✅ เปิดตัวจัดการรูป: ดู/ลบรูปเดิม + เพิ่มรูปใหม่ แล้วบันทึกกลับเข้า DB
                const safeUrl = (task.image_url || '').replace(/'/g, "\\'");
const hasImages = !!task.image_url;

const actionText = hasImages ? 'ดู/ลบรูปภาพ' : 'แนบรูปภาพ';
const actionBg = hasImages ? '#f0f0f0' : '#00C3AA';
const actionColor = hasImages ? '#333' : 'white';
const actionOnClick = hasImages
  ? `window.openImageManager('${task.inspection_id}', '${safeUrl}')`
  : `window.triggerUpload('${task.inspection_id}')`;

                return `
            <div style="background:white; padding:15px; border-radius:8px; margin-bottom:10px; border:1px solid #eee; display:flex; justify-content:space-between; align-items:center;">
                <div>
                    <div style="font-weight:bold;">วันที่นัดหมาย: ${inspectionDate}</div>
                    <div style="font-size:12px; color:#666;">สถานะ: ${task.status}</div>
                    ${hasImgStatus}
                </div>
                <div>
                    <button onclick="${actionOnClick}" style="background:${actionBg}; color:${actionColor}; border:none; padding:8px 15px; border-radius:5px; cursor:pointer;">
                        <i class="fas fa-images"></i> ${actionText}
                    </button>
                </div>
            </div>
        `;
            }).join('');
        } else {
            // ไม่มีงาน
            if (placeholder) placeholder.classList.remove("hidden");
            taskList.innerHTML = '';
        }
    }
};

/* ======================================================
   3. HELPER FUNCTIONS (Upload, Payment, Modal)
   ====================================================== */

// ✅ Global: เก็บ inspection_id ของงานที่กำลังอัปโหลด (แบบเก่า)
window.currentUploadTaskId = null;

window.triggerUploadLatest = async () => {
    // ต้องล็อกอินก่อน
    if (!db.currentUser) {
        Swal.fire({ icon:'warning', title:'กรุณาเข้าสู่ระบบ', confirmButtonColor:'#00C3AA' });
        return;
    }

    // ดึง “งานล่าสุด” ของ user คนนี้
    const { data: latestTask, error } = await window._client
        .from('Inspection')
        .select('inspection_id')
        .order('created_at', { ascending: false })
        .limit(1)
        .single();

    if (error || !latestTask) {
        Swal.fire({
            icon:'warning',
            title:'ไม่พบงานให้แนบไฟล์',
            text:'กรุณาส่งคำขอตรวจ/ให้แอดมินสร้างงานก่อน',
            confirmButtonColor:'#00C3AA'
        });
        return;
    }

    // เรียกอัปโหลดแบบผูกกับงาน
    window.triggerUpload(latestTask.inspection_id);
};

window.triggerUpload = (taskId) => {
    window.currentUploadTaskId = taskId;  
    let uploader = document.getElementById('hidden-uploader');
    if (!uploader) {
        uploader = document.createElement('input');
        uploader.type = 'file';
        uploader.id = 'hidden-uploader';
        uploader.style.display = 'none';
        uploader.accept = 'image/*'; // หรือ image/*,.pdf ถ้าจะรับ pdf
        uploader.onchange = window.handleImageUpload;
        document.body.appendChild(uploader);
    }
    uploader.click();
};

window.handleImageUpload = async(event) => {
    const file = event.target.files[0];
    if (!file) return;

    // อนุญาตเฉพาะ รูป และ PDF
    const isImage = file.type.startsWith('image/');
    const isPDF = file.type === 'application/pdf';

    if (!isImage && !isPDF) {
        Swal.fire({
            icon: 'error',
            title: 'ไฟล์ไม่ถูกต้อง',
            text: 'รองรับเฉพาะรูปภาพ และ PDF เท่านั้น',
            confirmButtonColor: '#00C3AA'
        });
        event.target.value = '';
        return;
    }
    try {
        const result = await Swal.fire({
            title: 'ยืนยันการส่งรูปภาพ?',
            text: "คุณต้องการอัปโหลดรูปภาพนี้เข้าสู่ระบบใช่หรือไม่",
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#00C3AA',
            cancelButtonColor: '#aaa',
            confirmButtonText: 'ใช่, อัปโหลดเลย',
            cancelButtonText: 'ยกเลิก'
        });

        if (!result.isConfirmed) {
            event.target.value = '';
            return;
        }

        Swal.fire({
            title: 'กำลังอัปโหลด...',
            allowOutsideClick: false,
            didOpen: () => { Swal.showLoading(); }
        });

        const fileName = `${Date.now()}_${file.name.replace(/\s/g, '')}`;

        const { error: uploadError } = await window._client.storage.from('task-images').upload(fileName, file);
        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = window._client.storage.from('task-images').getPublicUrl(fileName);

        const { error: dbError } = await window._client.from('Inspection')
            .update({ image_url: publicUrl })
            .eq('inspection_id', window.currentUploadTaskId); 

        if (dbError) throw dbError;

        await Swal.fire({
            icon: 'success',
            title: 'อัปโหลดเรียบร้อย! ✅',
            timer: 1500,
            showConfirmButton: false
        });

        if (typeof db.renderDashboard === 'function') {
            db.renderDashboard();
        }

    } catch (err) {
        console.error("Upload Failed:", err);
        Swal.fire({
            icon: 'error',
            title: 'เกิดข้อผิดพลาด',
            text: err.message,
            confirmButtonColor: '#00C3AA'
        });
    } finally {
        event.target.value = '';
    }
};

/* ======================================================
   ฟังก์ชันสำหรับแสดงภาพ (รองรับหลายรูป)
   ====================================================== */
window.openFullImage = (srcString) => {
    const modal = document.getElementById('image-modal');
    
    // ลองหา container ที่ทำไว้รองรับหลายรูป
    const container = document.getElementById('multi-image-modal-content');
    const singleImg = document.getElementById('full-image-preview');

    if (modal) {
        if (container) {
            container.innerHTML = ''; // ล้างรูปเก่า
            const urls = srcString.split(','); 
            urls.forEach(url => {
                if(url.trim() !== '') {
                    container.innerHTML += `<img src="${url.trim()}" style="max-width:90%; border-radius:8px; margin-bottom: 15px; display:block; margin-left:auto; margin-right:auto;">`;
                }
            });
        } else if (singleImg) {
            // กรณีเป็นหน้าจอที่ยังมีแค่ img tag เดียว
            singleImg.src = srcString.split(',')[0];
        }
        modal.classList.remove('hidden');
    } else { 
        window.open(srcString.split(',')[0], '_blank'); 
    }
};

/* ======================================================
   ดู/แก้ไขรูปภาพที่เคยส่งแล้ว (User)
   - รองรับหลายรูป (คั่นด้วย ,)
   - ลบรูปเดิมบางรูปได้
   - เพิ่มรูปใหม่หลายรูปได้
   - บันทึกกลับไปที่ Inspection.image_url
   ====================================================== */
window.openImageManager = async function(inspectionId, srcString) {
  try {
    if (!window._client) throw new Error("Supabase client not ready");

    // ถ้าไม่มี SweetAlert2 ให้ fallback ไปเปิดรูปแบบเดิม
    if (typeof Swal === 'undefined') {
      return window.openFullImage(srcString || "");
    }

    const state = {
      taskId: inspectionId,
      existingUrls: (srcString || "")
        .split(",")
        .map(s => s.trim())
        .filter(Boolean)
    };

    const render = () => {
      const ex = state.existingUrls;

      const existingHtml = ex.length
        ? ex.map((u, i) => `
          <div style="position:relative; width:120px; height:120px; border-radius:12px; overflow:hidden; border:1px solid #e5e7eb; background:#f8fafc;">
            <img src="${u}" style="width:100%; height:100%; object-fit:cover; display:block;" />
            <button data-remove-existing="${i}"
              title="ลบรูปนี้ออกจากรายการ"
              style="position:absolute; top:8px; right:8px; width:28px; height:28px; border:none; border-radius:999px; cursor:pointer; background:#ef4444; color:white; font-weight:800; line-height:28px;">
              ×
            </button>
          </div>
        `).join("")
        : `<div style="color:#94a3b8; padding:10px 0;">ยังไม่มีรูปภาพในรายการนี้</div>`;

      return `
        <div style="text-align:left;">
          <div style="font-weight:700; margin-bottom:10px;">รูปที่เคยส่ง (กด × เพื่อลบออกจากรายการ)</div>
          <div id="imgmgr-existing" style="display:flex; gap:12px; flex-wrap:wrap;">
            ${existingHtml}
          </div>

          <div style="margin-top:14px; font-size:12px; color:#64748b;">
            หน้านี้ใช้สำหรับ <b>ดูรูปและลบ</b> เท่านั้น (การอัปโหลด/แนบรูปใหม่ให้ทำจากปุ่ม “แนบรูปภาพ” ในหน้าส่งข้อมูล)
          </div>
        </div>
      `;
    };

    const bindEvents = () => {
      const root = Swal.getHtmlContainer();
      if (!root) return;

      root.querySelectorAll("[data-remove-existing]").forEach(btn => {
        btn.addEventListener("click", () => {
          const idx = Number(btn.getAttribute("data-remove-existing"));
          if (Number.isNaN(idx)) return;

          state.existingUrls.splice(idx, 1);
          Swal.update({ html: render() });
          bindEvents();
        });
      });
    };

    const res = await Swal.fire({
      title: "ดู/ลบรูปภาพ",
      html: render(),
      width: 760,
      showCancelButton: true,
      confirmButtonText: "บันทึกการลบ",
      cancelButtonText: "ปิด",
      confirmButtonColor: "#00C3AA",
      didOpen: () => bindEvents(),
      preConfirm: async () => {
        try {
          Swal.showLoading();

          const finalString = state.existingUrls.join(",");

          const { error: dbError } = await window._client
            .from("Inspection")
            .update({ image_url: finalString || null })
            .eq("inspection_id", state.taskId);

          if (dbError) throw dbError;
          return true;
        } catch (err) {
          Swal.showValidationMessage(err?.message || "บันทึกไม่สำเร็จ");
          return false;
        }
      }
    });

    if (res.isConfirmed) {
      await Swal.fire({
        icon: "success",
        title: "อัปเดตเรียบร้อย ✅",
        timer: 1100,
        showConfirmButton: false
      });

      if (window.db && typeof window.db.renderDashboard === "function") {
        window.db.renderDashboard();
      }
    }
  } catch (e) {
    console.error(e);
    alert(e?.message || "เกิดข้อผิดพลาด");
  }
};

;

/* ======================================================
   TASK MANAGEMENT (Admin)
   ====================================================== */
window.saveTask = async function() {
    const getValue = (id) => {
        const el = document.getElementById(id);
        return el ? el.value : "";
    };

    const id = getValue("task-id");
    const customerName = getValue("task-customer-name");
    const title = getValue("task-title");
    const description = getValue("task-description");
    const status = getValue("task-status") || "pending";
    const priority = getValue("task-priority") || "Medium";
    const date = getValue("task-due");

    try {
        Swal.fire({
            title: 'กำลังบันทึก...',
            allowOutsideClick: false,
            didOpen: () => { Swal.showLoading(); }
        });

        const taskData = {
            restaurant_name: customerName || "ทั่วไป",
            title: title || "งานตรวจใหม่",
            status: status || "pending",
            priority: priority || "Medium",
            inspection_date: date || new Date().toISOString().split('T')[0],
            result: "-",
            description: description || ""
        };

        if (id && id.trim() !== "") {
            const { error } = await window._client.from('Inspection').update(taskData).eq('inspection_id', id);
            if (error) throw error;
        } else {
            taskData.inspection_id = "INS-" + Date.now();
            const { error } = await window._client.from('Inspection').insert([taskData]);
            if (error) throw error;
        }

        window.closeModal('task-modal');
        document.getElementById("task-id").value = "";
        const form = document.querySelector('#task-modal form');
        if (form) form.reset();

        Swal.fire({
            icon: 'success',
            title: 'บันทึกสำเร็จ',
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 1500
        });

        const tbody = document.getElementById("admin-task-table");
        if (tbody) tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;">🔄 กำลังอัปเดตข้อมูล...</td></tr>';

        setTimeout(async() => {
            console.log("Re-rendering table...");
            if (window.db && typeof window.db.renderAdminTable === 'function') {
                await window.db.renderAdminTable();
            } else if (typeof renderAdminTable === 'function') {
                await renderAdminTable();
            } else {
                window.location.reload();
            }
        }, 500);

    } catch (e) {
        console.error("Save Task Error:", e);
        Swal.fire({
            icon: 'error',
            title: 'บันทึกไม่สำเร็จ',
            text: `Error: ${e.message}`
        });
    }
};

window.openTaskModal = async(id = null) => {
    window.openModal('task-modal');

    document.getElementById("task-id").value = id || "";
    document.getElementById("task-customer-name").value = "";
    document.getElementById("task-title").value = "";
    document.getElementById("task-description").value = "";
    document.getElementById("task-status").value = "pending";
    document.getElementById("task-priority").value = "Medium";
    document.getElementById("task-due").value = "";

    const imgEl = document.getElementById("admin-task-img");
    const placeholder = document.getElementById("img-placeholder");

    if (imgEl) imgEl.classList.add("hidden");
    if (placeholder) {
        placeholder.classList.remove("hidden");
        placeholder.innerText = id ? "กำลังโหลดข้อมูล..." : "ไม่มีรูปภาพประกอบ";
    }

    if (id) {
        let { data: task } = await window._client
            .from('Inspection')
            .select('*')
            .eq('inspection_id', id)
            .single();

        if (task) {
            if (document.getElementById("task-customer-name"))
                document.getElementById("task-customer-name").value = task.restaurant_name || "";

            if (document.getElementById("task-title"))
                document.getElementById("task-title").value = task.title || "";

            if (document.getElementById("task-description"))
                document.getElementById("task-description").value = task.description || "";

            document.getElementById("task-status").value = task.status || "pending";
            document.getElementById("task-priority").value = task.priority || "Medium";
            document.getElementById("task-due").value = task.inspection_date || "";

            if (task.image_url) {
                if (imgEl) {
                    imgEl.src = task.image_url.split(',')[0]; // โชว์รูปแรก
                    imgEl.classList.remove("hidden");
                }
                if (placeholder) placeholder.classList.add("hidden");
            } else {
                if (placeholder) placeholder.innerText = "ร้านค้านี้ยังไม่ได้แนบรูปภาพ";
            }
        }
    }
};

window.deleteTask = async function() {
    const id = document.getElementById("task-id").value;
    if (!id) return; 

    const confirm = await Swal.fire({
        title: 'ยืนยันการลบงาน?',
        text: "หากลบแล้วข้อมูลนี้จะหายไปถาวร!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#dc2626',
        confirmButtonText: 'ใช่, ลบเลย',
        cancelButtonText: 'ยกเลิก'
    });

    if (confirm.isConfirmed) {
        try {
            Swal.fire({ title: 'กำลังลบ...', didOpen: () => Swal.showLoading() });

            const { error } = await window._client
                .from('Inspection')
                .delete()
                .eq('inspection_id', id);

            if (error) throw error;

            await Swal.fire({ icon: 'success', title: 'ลบสำเร็จ!', timer: 1500, showConfirmButton: false });

            window.closeModal('task-modal');
            if (window.db && typeof window.db.renderAdminTable === 'function') {
                await window.db.renderAdminTable();
            }
        } catch (e) {
            Swal.fire('เกิดข้อผิดพลาด', e.message, 'error');
        }
    }
};

window.deleteTaskDirect = async function(id) {
    if (!id) return;

    const confirm = await Swal.fire({
        title: 'ยืนยันการลบ?',
        text: "คุณต้องการลบรายการนี้ใช่หรือไม่?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ef4444',
        confirmButtonText: 'ลบข้อมูล',
        cancelButtonText: 'ยกเลิก'
    });

    if (confirm.isConfirmed) {
        try {
            Swal.fire({ title: 'กำลังลบ...', didOpen: () => Swal.showLoading() });

            const { error } = await window._client
                .from('Inspection')
                .delete()
                .eq('inspection_id', id);

            if (error) throw error;

            await Swal.fire({ icon: 'success', title: 'ลบสำเร็จ', timer: 800, showConfirmButton: false });

            setTimeout(async() => {
                const tbody = document.getElementById("admin-task-table");
                if (tbody) tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;">กำลังโหลด...</td></tr>';

                if (window.db && window.db.renderAdminTable) {
                    await window.db.renderAdminTable();
                } else {
                    window.location.reload();
                }
            }, 300);

        } catch (e) {
            Swal.fire('เกิดข้อผิดพลาด', e.message, 'error');
        }
    }
};

/* ======================================================
   MULTI-IMAGE UPLOAD & SUBMIT REQUEST (ระบบใหม่)
   ====================================================== */
window.selectedImages = [];

// ดักจับการเลือกไฟล์หลายรูป
document.addEventListener('DOMContentLoaded', () => {
    const evImagesInput = document.getElementById('ev-images');
    if (evImagesInput) {
        evImagesInput.addEventListener('change', function(event) {
            const files = Array.from(event.target.files);
            window.selectedImages = window.selectedImages.concat(files);
            window.renderImagePreviews();
            event.target.value = ''; 
        });
    }
});

window.renderImagePreviews = function() {
    const container = document.getElementById('preview-container');
    if (!container) return;
    
    container.innerHTML = ''; 
    
    if (window.selectedImages.length === 0) {
        container.innerHTML = '<p id="empty-preview-text" style="color: #94a3b8; width: 100%; text-align: center; margin-top: 60px;">ยังไม่มีรูปภาพ กรุณาอัปโหลด</p>';
        return;
    }
    
    window.selectedImages.forEach((file, index) => {
        const objectUrl = URL.createObjectURL(file);
        const div = document.createElement('div');
        div.className = 'preview-box';
        div.innerHTML = `
            <img src="${objectUrl}" alt="preview">
            <span class="remove-img-btn" onclick="window.removeImage(${index})" title="ลบรูปภาพ">&times;</span>
        `;
        container.appendChild(div);
    });
};

window.removeImage = function(index) {
    window.selectedImages.splice(index, 1);
    window.renderImagePreviews();
};

window.submitInspectionRequest = async function(event) {
    if (event && event.preventDefault) {
        event.preventDefault();
    }

    var currentUser = window.db && window.db.currentUser ? window.db.currentUser : JSON.parse(localStorage.getItem('hygieUser'));

    if (!currentUser) {
        Swal.fire({
            icon: 'error',
            title: 'เซสชั่นหมดอายุ',
            text: 'กรุณาเข้าสู่ระบบใหม่เพื่อดำเนินการครับ',
            confirmButtonColor: '#00C3AA'
        });
        return;
    }

    try {
        const confirmResult = await Swal.fire({
            title: 'ยืนยันการส่งคำขอ?',
            text: "คุณต้องการส่งคำขอและแจ้งเตือนเจ้าหน้าที่ใช่หรือไม่",
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#00C3AA',
            cancelButtonColor: '#aaa',
            confirmButtonText: 'ใช่, ส่งคำขอเลย',
            cancelButtonText: 'ยกเลิก'
        });

        if (!confirmResult.isConfirmed) return;

        var btn = event ? event.target.closest('button') : document.getElementById('btn-submit-inspection');
        var originalText = btn ? btn.innerHTML : "ส่งคำขอรับการตรวจมาตรฐาน";

        if (btn) {
            btn.disabled = true;
            btn.innerHTML = "กำลังค้นหางาน...";
        }

        const myName = currentUser.restaurant_name || currentUser.first_name;

        const response = await window._client
            .from('Inspection')
            .select('inspection_id, status, restaurant_name')
            .eq('restaurant_name', myName)
            .neq('status', 'completed')
            .order('created_at', { ascending: false })
            .limit(1)
            .single();

        const latestTask = response.data;
        const error = response.error;

        if (!latestTask || error) {
            Swal.fire({
                icon: 'warning',
                title: 'ไม่พบรายการตรวจ',
                text: 'ไม่พบงานที่ค้างอยู่ในระบบ กรุณาติดต่อแอดมินเพื่อสร้างงานตรวจก่อนครับ',
                confirmButtonColor: '#FFB74D'
            });
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = originalText;
            }
            return;
        }

        if (btn) btn.innerHTML = "กำลังส่งข้อมูล...";

        let finalImageUrls = null;

        // ถ้า User มีการเลือกรูปภาพหลายรูป ให้ทำการอัปโหลดก่อน
        if (window.selectedImages.length > 0) {
            let uploadedUrls = [];
            for (let i = 0; i < window.selectedImages.length; i++) {
                const file = window.selectedImages[i];
                const fileExt = file.name.split('.').pop();
                const fileName = `${Date.now()}_${Math.random().toString(36).substring(7)}.${fileExt}`;
                const filePath = `${currentUser.email}/${fileName}`; 

                const { data: uploadData, error: uploadError } = await window._client
                    .storage
                    .from('task-images') 
                    .upload(filePath, file);

                if (uploadError) throw uploadError;

                const { data: publicUrlData } = window._client
                    .storage
                    .from('task-images')
                    .getPublicUrl(filePath);

                uploadedUrls.push(publicUrlData.publicUrl);
            }
            finalImageUrls = uploadedUrls.join(',');
        }

        // อัปเดตข้อมูลลงฐานข้อมูล
        let updatePayload = {
            status: 'pending',
            updated_at: new Date().toISOString()
        };

        if (finalImageUrls) {
            updatePayload.image_url = finalImageUrls;
        }

        const { error: updateError } = await window._client
            .from('Inspection')
            .update(updatePayload)
            .eq('inspection_id', latestTask.inspection_id);

        if (updateError) throw updateError;

        await Swal.fire({
            icon: 'success',
            title: 'ส่งคำขอสำเร็จ!',
            text: 'ระบบได้รับคำขอแล้ว เจ้าหน้าที่จะติดต่อกลับเร็วๆ นี้ ✅',
            confirmButtonColor: '#00C3AA'
        });

        // ล้างรูปภาพที่พรีวิวไว้
        window.selectedImages = [];
        if (window.renderImagePreviews) window.renderImagePreviews();

        window.location.reload();

    } catch (err) {
        console.error("Submit Error:", err);
        Swal.fire({
            icon: 'error',
            title: 'เกิดข้อผิดพลาด',
            text: 'ไม่สามารถบันทึกข้อมูลได้: ' + err.message,
            confirmButtonColor: '#EF4444'
        });
    } finally {
        const finalBtn = document.querySelector('button[onclick*="submitInspectionRequest"]');
        if (finalBtn) {
            finalBtn.disabled = false;
            finalBtn.innerHTML = '<i class="fas fa-save"></i> บันทึกและส่งคำขอตรวจ';
        }
    }
};

/* ======================================================
   5. PACKAGE & AUTH METHODS
   ====================================================== */
window.handlePackageSelection = function(planName, price) {
    const user = localStorage.getItem('hygieUser');

    if (user) {
        window.location.href = `payment.html?plan=${encodeURIComponent(planName)}&price=${price}`;
    } else {
        localStorage.setItem('pendingPaymentUrl', `payment.html?plan=${encodeURIComponent(planName)}&price=${price}`);
        Swal.fire({
            title: 'ก้าวเดียวสู่การจัดการที่ดีขึ้น!',
            text: 'กรุณาเข้าสู่ระบบเพื่อดำเนินการสั่งซื้อแพ็คเกจ ' + planName,
            icon: 'info',
            confirmButtonColor: '#00C3AA',
            confirmButtonText: 'เข้าสู่ระบบ / ลงทะเบียน',
            allowOutsideClick: false
        }).then((result) => {
            if (result.isConfirmed) {
                window.openModal('auth-modal');
            }
        });
    }
};

let isRegisterMode = false;

window.toggleAuthMode = () => {
    isRegisterMode = !isRegisterMode;
    const title = document.getElementById("auth-title");
    const btn = document.getElementById("auth-btn-submit");
    const regFields = document.getElementById("register-fields");
    const toggleText = document.getElementById("auth-toggle-text");
    const toggleLink = document.getElementById("auth-toggle-link");

    if (!regFields) {
        console.warn("Register fields missing in HTML");
        return;
    }

    if (isRegisterMode) {
        title.innerText = "สมัครสมาชิกใหม่";
        btn.innerText = "ลงทะเบียน";
        btn.style.background = "#2563eb";
        regFields.classList.remove("hidden");
        toggleText.innerText = "มีบัญชีอยู่แล้ว?";
        toggleLink.innerText = "เข้าสู่ระบบ";
    } else {
        title.innerText = "เข้าสู่ระบบ";
        btn.innerText = "เข้าสู่ระบบ";
        btn.style.background = "#00C3AA";
        regFields.classList.add("hidden");
        toggleText.innerText = "ยังไม่มีบัญชี?";
        toggleLink.innerText = "สมัครสมาชิก";
    }
};

window.handleAuthSubmit = async(e) => {
    e.preventDefault();

    const btn = document.getElementById("auth-btn-submit");
    const originalText = btn ? btn.innerHTML : (isRegisterMode ? "ลงทะเบียน" : "เข้าสู่ระบบ");

    const emailEl = document.getElementById("auth-email");
    const passEl = document.getElementById("auth-pass");

    if (!emailEl || !passEl) {
        const oldUser = document.getElementById("auth-user");
        if (oldUser && passEl) {
            db.login(oldUser.value, passEl.value);
            return;
        }

        Swal.fire({
            icon: 'error',
            title: 'ระบบขัดข้อง',
            text: 'ไม่พบช่องกรอกข้อมูลในหน้านี้',
            confirmButtonColor: '#00C3AA'
        });
        return;
    }

    const email = emailEl.value.trim();
    const pass = passEl.value.trim();

    if (!email || !pass) {
        Swal.fire({
            icon: 'warning',
            title: 'ข้อมูลไม่ครบ',
            text: 'กรุณากรอกอีเมลและรหัสผ่านให้ครบถ้วนครับ',
            confirmButtonColor: '#00C3AA'
        });
        return;
    }

    const getVal = (id) => {
        const el = document.getElementById(id);
        return el ? el.value.trim() : "";
    };

    try {
        if (btn) {
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังดำเนินการ...';
        }

        if (isRegisterMode) {
            const confirmPass = getVal("auth-confirm-pass");

            if (pass !== confirmPass) {
                Swal.fire({
                    icon: 'error',
                    title: 'รหัสผ่านไม่ตรงกัน',
                    text: 'กรุณาตรวจสอบการยืนยันรหัสผ่านอีกครั้ง ❌',
                    confirmButtonColor: '#00C3AA'
                });
                return;
            }

            const formData = {
                email: email,
                password_hash: pass,
                first_name: getVal("reg-fname"),
                last_name: getVal("reg-lname"),
                phone: getVal("reg-phone"),
                restaurant_name: getVal("reg-shop-name"),
                restaurant_address: getVal("reg-address"),
                subdistrict: getVal("reg-subdistrict"),
                district: getVal("reg-district"),
                province: getVal("reg-province"),
                postal_code: getVal("reg-zip"),
                role: 'user',
                status: 'active',
                created_at: new Date().toISOString()
            };

            if (!formData.first_name || !formData.restaurant_name || !formData.phone) {
                Swal.fire({
                    icon: 'warning',
                    title: 'ข้อมูลไม่ครบถ้วน',
                    text: 'กรุณากรอกชื่อจริง, เบอร์โทร และชื่อร้านให้ครบถ้วนนะครับ',
                    confirmButtonColor: '#00C3AA'
                });
                return;
            }

            await db.register(formData);

        } else {
            await db.login(email, pass);
        }

    } catch (err) {
        console.error("Auth Error:", err);
        Swal.fire({
            icon: 'error',
            title: 'เกิดข้อผิดพลาด',
            text: 'ระบบไม่สามารถดำเนินการได้ในขณะนี้',
            confirmButtonColor: '#00C3AA'
        });
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = originalText;
        }
    }
};

/* ======================================================
   6. USER PROFILE & ACCOUNT DELETE
   ====================================================== */
window.openProfileModal = function() {
    if (!db.currentUser) {
        Swal.fire({
            icon: 'error',
            title: 'เซสชั่นหมดอายุ',
            text: 'กรุณาเข้าสู่ระบบใหม่อีกครั้งเพื่อดูข้อมูลส่วนตัวครับ',
            confirmButtonColor: '#00C3AA',
            confirmButtonText: 'ไปที่หน้าล็อกอิน'
        }).then((result) => {
            if (result.isConfirmed) {
                window.openModal('auth-modal');
            }
        });
        return;
    }

    const user = db.currentUser;
    const setVal = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.value = val || '';
    };

    setVal('edit-email', user.email);
    setVal('edit-fname', user.first_name);
    setVal('edit-lname', user.last_name);
    setVal('edit-phone', user.phone);
    setVal('edit-shop-name', user.restaurant_name);
    setVal('edit-address', user.restaurant_address);
    setVal('edit-subdistrict', user.subdistrict);
    setVal('edit-district', user.district);
    setVal('edit-province', user.province);
    setVal('edit-zip', user.postal_code);

    window.openModal('profile-modal');
};

window.saveProfile = async function() {
    const btn = document.querySelector('#profile-modal .btn-full-green');
    const originalText = btn.innerText;
    btn.innerText = "กำลังบันทึก...";
    btn.disabled = true;

    try {
        const updates = {
            first_name: document.getElementById('edit-fname').value,
            last_name: document.getElementById('edit-lname').value,
            phone: document.getElementById('edit-phone').value,
            restaurant_name: document.getElementById('edit-shop-name').value,
            restaurant_address: document.getElementById('edit-address').value,
            subdistrict: document.getElementById('edit-subdistrict').value,
            district: document.getElementById('edit-district').value,
            province: document.getElementById('edit-province').value,
            postal_code: document.getElementById('edit-zip').value,
            updated_at: new Date().toISOString()
        };

        const { data, error } = await window._client
            .from('Users')
            .update(updates)
            .eq('user_id', db.currentUser.user_id)
            .select()
            .single();

        if (error) throw error;

        const newUserData = {...db.currentUser, ...updates };
        localStorage.setItem('hygieUser', JSON.stringify(newUserData));
        db.currentUser = newUserData;

        Swal.fire({
            icon: 'success',
            title: 'อัปเดตข้อมูลสำเร็จ!',
            text: 'ข้อมูลโปรไฟล์ของคุณถูกบันทึกเรียบร้อยแล้ว ✅',
            timer: 2000,
            showConfirmButton: false
        });

        window.closeModal('profile-modal');
        await db.renderDashboard();
        db.updateNav();

    } catch (err) {
        console.error("Update Failed:", err);
        Swal.fire({
            icon: 'error',
            title: 'บันทึกไม่สำเร็จ',
            text: 'เกิดข้อผิดพลาด: ' + err.message,
            confirmButtonColor: '#00C3AA'
        });
    } finally {
        btn.innerText = originalText;
        btn.disabled = false;
    }
};

window.deleteAccount = async function() {
    if (!db.currentUser) return;

    const swalConfig = {
        target: document.getElementById('profile-modal') || document.body,
        didOpen: () => {
            const container = Swal.getContainer();
            if (container) container.style.zIndex = '1000001';
        }
    };

    const result1 = await Swal.fire({
        title: 'ยืนยันการลบบัญชี?',
        text: "❗ ข้อมูลร้านค้าและประวัติการตรวจทั้งหมดจะหายไปถาวร!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#dc2626',
        cancelButtonColor: '#64748b',
        confirmButtonText: 'ใช่, ต้องการลบ',
        cancelButtonText: 'ยกเลิก'
    });

    if (!result1.isConfirmed) return;

    const result2 = await Swal.fire({
        title: 'คุณแน่ใจจริงๆ นะ?',
        text: "⚠️ การกระทำนี้ไม่สามารถย้อนกลับได้!",
        icon: 'error',
        showCancelButton: true,
        confirmButtonColor: '#b91c1c',
        cancelButtonColor: '#64748b',
        confirmButtonText: 'ยืนยันลบถาวร',
        cancelButtonText: 'เปลี่ยนใจแล้ว'
    });

    if (!result2.isConfirmed) return;

    try {
        Swal.fire({
            ...swalConfig,
            title: 'กำลังลบข้อมูล...',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
                Swal.getContainer().style.zIndex = '1000001';
            }
        });

        const userId = db.currentUser.user_id;
        const { error } = await window._client
            .from('Users')
            .delete()
            .eq('user_id', userId);

        if (error) throw error;

        await Swal.fire({
            ...swalConfig,
            icon: 'success',
            title: 'ลบบัญชีเรียบร้อยแล้ว',
            text: 'หวังว่าจะได้พบกันใหม่ในโอกาสหน้านะครับ 👋',
            timer: 3000,
            showConfirmButton: false
        });

        db.logout();

    } catch (err) {
        console.error("Delete Error:", err);
        Swal.fire({
            ...swalConfig,
            icon: 'error',
            title: 'เกิดข้อผิดพลาด',
            text: 'ไม่สามารถลบบัญชีได้ในขณะนี้: ' + err.message,
            confirmButtonColor: '#00C3AA'
        });
    }
};

/* ======================================================
   7. GLOBAL HELPERS
   ====================================================== */
window.openModal = (id) => {
    const m = document.getElementById(id);
    if (m) {
        m.classList.remove("hidden");
        if (id === 'auth-modal' && isRegisterMode) toggleAuthMode(); 
    }
};

window.closeModal = (id) => {
    const el = document.getElementById(id);
    if (el) el.classList.add("hidden");
};

window.showView = (id) => {
    const sections = document.querySelectorAll('.view-section');
    sections.forEach(v => {
        v.classList.add('hidden');
    });

    const targetView = document.getElementById(id);
    if (targetView) {
        targetView.classList.remove('hidden');
    }
};

/* ======================================================
   8. TRACKING, QUEUE & OTHERS
   ====================================================== */
const syncCardData = () => {
    const inputNum = document.getElementById('cardNumber');
    const inputName = document.getElementById('payerName');
    const inputExp = document.getElementById('cardExp');
    const inputCvv = document.getElementById('cardCvv');

    if (inputNum) {
        inputNum.addEventListener('input', (e) => {
            let val = e.target.value.replace(/\D/g, ''); 
            val = val.substring(0, 16); // บังคับ 16 หลัก
            let formatted = val.replace(/(.{4})/g, '$1 ').trim();
            e.target.value = formatted;
            const viewNum = document.getElementById('view-number');
            if(viewNum) viewNum.textContent = formatted || "•••• •••• •••• ••••";
        });
    }

    if (inputName) {
        inputName.addEventListener('input', (e) => {
            const viewName = document.getElementById('view-name');
            if(viewName) viewName.textContent = e.target.value.toUpperCase() || "CUSTOMER NAME";
        });
    }

    if (inputExp) {
        inputExp.addEventListener('input', (e) => {
            let val = e.target.value.replace(/\D/g, '');
            if (val.length >= 2) val = val.substring(0, 2) + '/' + val.substring(2, 4);
            e.target.value = val;
            const viewExp = document.getElementById('view-expiry');
            if(viewExp) viewExp.textContent = val || "MM/YY";
        });
    }

    if (inputCvv) {
        inputCvv.addEventListener('input', (e) => {
            const viewCvv = document.getElementById('view-cvv');
            if(viewCvv) viewCvv.textContent = "CVV: " + (e.target.value || "***");
        });
    }
};

async function loadTrackingInfo() {
    const currentUser = JSON.parse(localStorage.getItem('hygieUser'));
    if (!currentUser) return;

    const myName = currentUser.restaurant_name || currentUser.first_name;
    const shopNameDisplay = document.getElementById('track-shop-name');
    if(shopNameDisplay) shopNameDisplay.innerText = myName;

    const { data: queueList, error } = await window._client
        .from('Inspection')
        .select('*')
        .neq('status', 'completed') 
        .order('inspection_date', { ascending: true }) 
        .order('created_at', { ascending: true }); 

    if (error) {
        console.error("Load Queue Error:", error);
        return;
    }

    const myIndex = queueList.findIndex(item =>
        (item.restaurant_name && item.restaurant_name.trim() === myName.trim()) ||
        (item.user_id && item.user_id === currentUser.id)
    );

    if (myIndex !== -1) {
        const myTask = queueList[myIndex];
        const queueNo = myIndex + 1; 

        if(document.getElementById('track-queue-no')) document.getElementById('track-queue-no').innerText = queueNo;
        if(document.getElementById('track-current-status')) document.getElementById('track-current-status').innerText = translateStatus(myTask.status);
        if(document.getElementById('track-desc')) document.getElementById('track-desc').innerText = myTask.description || "กำลังดำเนินการตามขั้นตอน...";

        updateProgressBar(myTask.status);
    } else {
        if(document.getElementById('track-queue-no')) document.getElementById('track-queue-no').innerText = "-";
        if(document.getElementById('track-current-status')) document.getElementById('track-current-status').innerText = "ไม่มีงานค้าง";
        if(document.getElementById('track-desc')) document.getElementById('track-desc').innerText = "คุณไม่มีคิวงานที่กำลังดำเนินการ หรือการตรวจสอบเสร็จสิ้นแล้ว";
        resetProgressBar();
    }
}

function updateProgressBar(status) {
    document.querySelectorAll('.step, .line').forEach(el => el.classList.remove('active'));

    const steps = ['pending', 'traveling', 'inspecting', 'completed'];
    let foundCurrent = false;

    steps.forEach((stepName, index) => {
        const stepEl = document.getElementById('step-' + stepName);
        if (stepEl && !foundCurrent) {
            stepEl.classList.add('active');

            if (index < steps.length - 1) {
                if (status === stepName) {
                    foundCurrent = true; 
                } else {
                    const nextLine = stepEl.nextElementSibling;
                    if (nextLine && nextLine.classList.contains('line')) nextLine.classList.add('active');
                }
            }
        }
    });
}

function translateStatus(status) {
    const dict = {
        'pending': 'รอคิวตรวจสอบ',
        'traveling': 'กำลังเดินทาง',
        'inspecting': 'กำลังตรวจหน้างาน',
        'completed': 'เสร็จสิ้น'
    };
    return dict[status] || status;
}

async function loadMyTasks() {
    const currentUser = JSON.parse(localStorage.getItem('hygieUser'));
    if (!currentUser) return; 

    const myName = currentUser.restaurant_name || currentUser.first_name;
    
    const { data: list, error } = await window._client
        .from('Inspection')
        .select('*')
        .eq('restaurant_name', myName) 
        .order('created_at', { ascending: false });

    if (error) {
        console.error("Supabase Error:", error);
        return;
    }

    const tbody = document.getElementById('jobList') || document.querySelector('tbody');
    if (!tbody) return; 

    if (list.length === 0) {
        tbody.innerHTML = `<tr><td colspan="4" style="text-align:center; padding: 20px;">ไม่พบข้อมูลงาน</td></tr>`;
        return;
    }

    tbody.innerHTML = list.map(i => {
        let statusColor = 'gray';
        let statusText = i.status;

        if (i.status === 'pending') {
            statusColor = 'orange';
            statusText = 'รอคิว';
        } else if (i.status === 'completed') {
            statusColor = 'green';
            statusText = 'เสร็จสิ้น';
        } else if (i.status === 'inspecting') {
            statusColor = 'blue';
            statusText = 'กำลังตรวจ';
        }

        return `
            <tr>
                <td>${i.restaurant_name}</td>
                <td><span style="color:${statusColor}; font-weight:bold;">${statusText}</span></td>
                <td>${i.inspection_date || '-'}</td>
                <td>${i.location || '-'}</td>
            </tr>
        `;
    }).join('');
}

async function loadCustomerDashboard() {
    var userStr = localStorage.getItem('hygieUser');
    if (!userStr) return;
    var currentUser = JSON.parse(userStr);

    var myName = currentUser.restaurant_name || currentUser.first_name;

    if (document.getElementById('user-name-display'))
        document.getElementById('user-name-display').innerText = currentUser.first_name;
    if (document.getElementById('user-shop-display'))
        document.getElementById('user-shop-display').innerText = myName;

    try {
        var response = await window._client
            .from('Inspection')
            .select('*')
            .neq('status', 'completed')
            .order('created_at', { ascending: true });

        var allQueue = response.data || [];

        var myQueueNo = "-";
        var myTask = null;

        for (var i = 0; i < allQueue.length; i++) {
            if (allQueue[i].restaurant_name.trim() === myName.trim()) {
                myTask = allQueue[i];
                myQueueNo = i + 1;
                break;
            }
        }

        var queueBox = document.getElementById('user-queue');
        if (queueBox) {
            queueBox.innerText = (myQueueNo !== "-") ? "คิวที่ " + myQueueNo : "-";
            if (myQueueNo === 1) queueBox.style.color = "#d97706";
            else queueBox.style.color = "#0f172a";
        }

        var descBox = document.getElementById('admin-desc-text');
        var packageBox = document.getElementById('active-package');

        if (myTask) {
            if (descBox) descBox.innerText = myTask.description || "- กำลังดำเนินการตามคิว -";
            if (packageBox) packageBox.innerText = translateStatus(myTask.status);
            updateMyProgressBar(myTask.status);
        } else {
            if (descBox) descBox.innerText = "ไม่มีรายการตรวจสอบในขณะนี้";
            if (packageBox) packageBox.innerText = "พร้อมรับบริการ";
            updateMyProgressBar('none');
        }

    } catch (err) {
        console.error("Dashboard Error:", err);
    }
}

function updateMyProgressBar(status) {
    var allSteps = ['st-pending', 'st-inspecting', 'st-completed'];
    allSteps.forEach(function(id) {
        var el = document.getElementById(id);
        if (el) el.classList.remove('active');
    });

    var w = '0%';

    function active(id) {
        var el = document.getElementById(id);
        if (el) el.classList.add('active');
    }

    if (status === 'pending') {
        w = '15%';
        active('st-pending');
    } else if (status === 'traveling') {
        w = '50%';
        active('st-pending');
    } else if (status === 'inspecting') {
        w = '80%';
        active('st-pending');
        active('st-inspecting');
    } else if (status === 'completed') {
        w = '100%';
        active('st-pending');
        active('st-inspecting');
        active('st-completed');
    }

    var bar = document.getElementById('prog-bar-fill');
    if (bar) bar.style.width = w;
}

function resetProgressBar() {
    document.querySelectorAll('.step, .line').forEach(el => el.classList.remove('active'));
}

document.addEventListener('DOMContentLoaded', () => {
    db.init();
    syncCardData(); // เรียกใช้งาน Sync บัตรเครดิตถ้าหน้าปัจจุบันมี Form 
});