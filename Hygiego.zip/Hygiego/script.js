/* ======================================================
   1. CORE DATABASE & STATE MANAGEMENT
   ====================================================== */
   const db = {
    users: [], orders: [], tasks: [], currentUser: null,

    init: function() {
        // 1. โหลดข้อมูลจาก LocalStorage
        this.users = JSON.parse(localStorage.getItem('hygieUsersDB')) || this.getDefaultUsers();
        this.orders = JSON.parse(localStorage.getItem('hygieOrdersDB')) || this.getDefaultOrders();

        // 2. ดึง Session (จุดสำคัญที่ทำให้ไม่เด้งออก)
        const storedUser = localStorage.getItem('hygieUser');
        if (storedUser) {
            this.currentUser = JSON.parse(storedUser);
        }

        // 3. ป้องกันการเข้าหน้า Dashboard โดยไม่ Login
        if (window.location.pathname.includes("dashboard.html") && !this.currentUser) {
            window.location.href = "index.html";
            return;
        }

        this.updateUI();
    },

    saveUsers: function() { localStorage.setItem('hygieUsersDB', JSON.stringify(this.users)); },
    saveOrders: function() { localStorage.setItem('hygieOrdersDB', JSON.stringify(this.orders)); },
    saveSession: function() { localStorage.setItem('hygieUser', JSON.stringify(this.currentUser)); },

    updateUI: function() {
        const isDashboard = window.location.pathname.includes("dashboard.html");

        if (isDashboard && this.currentUser) {
            // ✅ หน้า Dashboard: แสดงข้อมูลตามคนที่ Login จริง
            const uName = document.getElementById('u-name');
            const uAvatar = document.getElementById('u-avatar');
            const roleBadge = document.getElementById('role-badge');
            
            if(uName) uName.innerText = this.currentUser.name;
            if(uAvatar) uAvatar.innerText = this.currentUser.name.charAt(0).toUpperCase();
            if(roleBadge) roleBadge.innerText = this.currentUser.role.toUpperCase();

            renderMenu();

            if (this.currentUser.role === 'admin') {
                renderAdminDashboard();
            } else {
                window.renderView('view-customer');
                loadCustomerData();
            }
        } else {
            // ✅ หน้าอื่นๆ (เช่น Index): อัปเดต Navbar ให้คงสภาพ Login
            window.updateNavAuth();
        }
    },

    logout: function() {
        localStorage.removeItem('hygieUser');
        alert("ออกจากระบบเรียบร้อย");
        window.location.href = "index.html";
    },

    getDefaultUsers: () => [
        { username: 'user', password: 'password', name: 'ร้านอาหารบ้านสวน', role: 'user', hasPaid: true, queue: 'Q-726' },
        { username: 'admin', password: 'password', name: 'ผู้ดูแลระบบสูงสุด', role: 'admin', hasPaid: true }
    ],
    getDefaultOrders: () => [
        { id: 101, queue: 'Q-726', customer: 'ร้านอาหารบ้านสวน', pkg: 'Smart Standard', price: 9900, status: 'Pending' },
        { id: 102, queue: 'Q-800', customer: 'ครัวคุณต๋อย', pkg: 'Starter', price: 0, status: 'Done' }
    ]
};

/* ======================================================
   2. AUTHENTICATION & NAV CONTROL
   ====================================================== */
let isRegisterMode = false;

window.updateNavAuth = function() {
    const navAuth = document.getElementById('nav-auth-section');
    if (!navAuth) return;

    if (db.currentUser) {
        // ✅ ถ้า Login อยู่แล้ว: แสดงชื่อและปุ่ม Dashboard แทนปุ่ม Login
        navAuth.innerHTML = `
            <div style="display:flex; align-items:center; gap:15px;">
                <div style="text-align:right; line-height:1.2;">
                    <div style="color:white; font-size:14px; font-weight:500;">${db.currentUser.name}</div>
                    <span style="font-size:10px; background:#00C3AA; color:white; padding:2px 6px; border-radius:4px;">${db.currentUser.role.toUpperCase()}</span>
                </div>
                <a href="dashboard.html" class="btn-login" style="text-decoration:none; padding:8px 16px; border:1px solid #00C3AA; border-radius:8px; color:white;">Dashboard</a>
                <button class="btn-login" onclick="db.logout()" style="background:#ff4757; border:none; padding:8px 16px; border-radius:8px; color:white; cursor:pointer;">Logout</button>
            </div>`;
    } else {
        // ถ้าไม่ได้ Login: แสดงปุ่มเข้าสู่ระบบปกติ
        navAuth.innerHTML = `<button class="btn-login" onclick="window.openModal('auth-modal')" style="background:transparent; border:1px solid #00C3AA; color:white; padding:8px 20px; border-radius:8px; cursor:pointer;">เข้าสู่ระบบ</button>`;
    }
};

window.handleAuthSubmit = function(e) {
    e.preventDefault();
    const userInp = document.getElementById('auth-user').value.trim();
    const passInp = document.getElementById('auth-pass').value.trim();

    if (isRegisterMode) {
        const nameInp = document.getElementById('auth-name').value.trim();
        if (db.users.find(u => u.username === userInp)) return alert("ชื่อผู้ใช้นี้ถูกใช้ไปแล้ว");

        const newUser = { 
            username: userInp, password: passInp, name: nameInp, 
            role: 'user', hasPaid: false, 
            queue: 'Q-' + Math.floor(Math.random() * 900 + 100) 
        };
        db.users.push(newUser);
        db.saveUsers();
        loginUser(newUser);
    } else {
        const foundUser = db.users.find(u => u.username === userInp && u.password === passInp);
        if (foundUser) loginUser(foundUser);
        else alert("ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง");
    }
};

function loginUser(user) {
    db.currentUser = user;
    db.saveSession();
    window.location.href = "dashboard.html";
}

window.toggleAuthMode = function() {
    isRegisterMode = !isRegisterMode;
    document.getElementById('group-name').classList.toggle('hidden');
    document.getElementById('auth-title').innerText = isRegisterMode ? "สร้างบัญชีใหม่" : "ยินดีต้อนรับกลับมา!";
    document.getElementById('auth-btn-submit').innerText = isRegisterMode ? "สมัครสมาชิก" : "เข้าสู่ระบบ";
};

window.openModal = function(id) { document.getElementById(id)?.classList.remove('hidden'); };
window.closeModal = function(id) { document.getElementById(id)?.classList.add('hidden'); };

/* ======================================================
   3. SIDEBAR & VIEW CONTROL
   ====================================================== */
window.renderView = function(viewId) {
    document.querySelectorAll('.view-section').forEach(el => el.classList.add('hidden'));
    const target = document.getElementById(viewId);
    if (target) {
        target.classList.remove('hidden');
        document.querySelectorAll('.menu a').forEach(a => a.classList.remove('active'));
        const activeLink = document.querySelector(`.menu a[onclick*="${viewId}"]`);
        if (activeLink) activeLink.classList.add('active');
    }
};

function renderMenu() {
    const menu = document.getElementById('sidebar-menu');
    if(!menu) return;
    
    let html = '';
    const role = db.currentUser.role;

    if (role === 'admin') {
        html += `<a href="#" onclick="renderAdminDashboard()" class="active"><i class="fas fa-chart-line"></i> ภาพรวมระบบ</a>`;
        html += `<a href="#" onclick="alert('จัดการสมาชิก')"><i class="fas fa-users-cog"></i> จัดการสมาชิก</a>`;
    } else {
        html += `<a href="#" onclick="window.renderView('view-customer')" class="active"><i class="fas fa-home"></i> ภาพรวม</a>`;
        html += `<a href="#" onclick="alert('เริ่มประเมิน')"><i class="fas fa-clipboard-check"></i> ประเมินตนเอง</a>`;
        if (db.currentUser.hasPaid) {
            html += `<a href="services.html"><i class="fas fa-certificate"></i> ใบรับรอง (E-Cert)</a>`;
        }
        html += `<a href="https://line.me/R/ti/p/@811cltri" target="_blank"><i class="fab fa-line"></i> แจ้งปัญหา</a>`;
    }
    html += `<a href="#" onclick="window.renderView('view-chat')"><i class="fas fa-comments"></i> ติดต่อเจ้าหน้าที่</a>`;
    menu.innerHTML = html;
}

/* ======================================================
   4. DASHBOARD RENDER LOGIC
   ====================================================== */
function loadCustomerData() {
    if(document.getElementById('user-name-display')) {
        document.getElementById('user-name-display').innerText = db.currentUser.name;
    }
    if(document.getElementById('user-queue')) {
        document.getElementById('user-queue').innerText = db.currentUser.queue || 'ไม่มีคิว';
    }
    if(document.getElementById('active-package')) {
        document.getElementById('active-package').innerText = db.currentUser.hasPaid ? "Smart Standard" : "Starter";
    }
    renderTrackingTimeline();
}

function renderTrackingTimeline() {
    const trackBox = document.getElementById("tracking-list");
    if (!trackBox) return;
    const steps = [
        { title: "ลงทะเบียน", desc: "สร้างบัญชีเรียบร้อย", status: "done" },
        { title: "ชำระเงิน", desc: db.currentUser.hasPaid ? "ชำระแล้ว" : "รอการชำระ", status: db.currentUser.hasPaid ? "done" : "active" },
        { title: "ประเมินตนเอง", desc: "รอทำรายการ", status: "pending" }
    ];
    trackBox.innerHTML = steps.map(s => `
        <div class="timeline-item ${s.status}">
            <div class="timeline-icon"><i class="fas fa-check"></i></div>
            <div class="timeline-content"><h4>${s.title}</h4><p>${s.desc}</p></div>
        </div>`).join('');
}

function renderAdminDashboard() {
    window.renderView('view-admin');
    const adminArea = document.getElementById('view-admin');
    const totalIncome = db.orders.reduce((sum, o) => sum + o.price, 0);
    const pendingOrders = db.orders.filter(o => o.status === 'Pending').length;

    adminArea.innerHTML = `
        <div class="admin-layout-content">
            <div class="dashboard-header">
                <h2>ภาพรวมระบบ (Admin Mode) 👋</h2>
                <p>สวัสดีคุณ <b>${db.currentUser.name}</b> ยินดีต้อนรับกลับมาครับ</p>
            </div>
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon bg-blue-soft"><i class="fas fa-wallet"></i></div>
                    <div><div class="stat-label">รายได้รวม</div><div class="stat-value">฿${totalIncome.toLocaleString()}</div></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon bg-orange-soft"><i class="fas fa-clock"></i></div>
                    <div><div class="stat-label">คิวที่รอดำเนินการ</div><div class="stat-value">${pendingOrders} งาน</div></div>
                </div>
            </div>
            <div class="modern-card" style="margin-top:20px;">
                <div class="card-head"><h3>จัดการรายการลูกค้าทั้งหมด</h3></div>
                <table class="admin-table">
                    <thead><tr><th>คิว</th><th>ร้านลูกค้า</th><th>แพ็คเกจ</th><th>สถานะ</th><th>จัดการ</th></tr></thead>
                    <tbody>
                        ${db.orders.map(o => `
                            <tr>
                                <td><b>${o.queue}</b></td>
                                <td>${o.customer}</td>
                                <td>${o.pkg}</td>
                                <td><span class="status-badge ${o.status.toLowerCase()}">${o.status}</span></td>
                                <td><button onclick="alert('แก้ไข ${o.queue}')" class="btn-sm">แก้ไข</button></td>
                            </tr>`).join('')}
                    </tbody>
                </table>
            </div>
        </div>`;
}

/* ======================================================
   5. AUTO-INJECT MODAL & INIT
   ====================================================== */
document.addEventListener("DOMContentLoaded", function() {
    if (!document.getElementById('auth-modal')) {
        document.body.insertAdjacentHTML('beforeend', `
        <div id="auth-modal" class="modal-overlay hidden">
            <div class="modal-content login-theme-modern" style="max-width: 400px; padding: 35px; text-align: center; background:white; border-radius:24px; position:relative; box-shadow:0 20px 40px rgba(0,0,0,0.2);">
                <span class="close-modal" onclick="window.closeModal('auth-modal')" style="position:absolute; right:20px; top:15px; cursor:pointer; font-size:24px; color:#94a3b8;">&times;</span>
                <div style="width:70px; height:70px; background:#f0fdfa; color:#00C3AA; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 20px; font-size:32px;"><i class="fas fa-shield-alt"></i></div>
                <h2 id="auth-title" style="margin-bottom:8px; color:#1e293b; font-size:24px;">ยินดีต้อนรับกลับมา!</h2>
                <p id="auth-subtitle" style="color:#64748b; font-size:14px; margin-bottom:25px;">ยินดีต้อนรับกลับสู่ HygieGo</p>
                <form onsubmit="window.handleAuthSubmit(event)">
                    <div id="group-name" class="hidden" style="margin-bottom:15px;">
                        <input type="text" id="auth-name" placeholder="ชื่อร้าน / ชื่อของคุณ" style="width:100%; padding:14px; border:1px solid #e2e8f0; border-radius:12px; font-size:15px; background:#f8fafc;">
                    </div>
                    <div style="margin-bottom:15px;"><input type="text" id="auth-user" placeholder="Username" required style="width:100%; padding:14px; border:1px solid #e2e8f0; border-radius:12px; font-size:15px; background:#f8fafc;"></div>
                    <div style="margin-bottom:20px;"><input type="password" id="auth-pass" placeholder="Password" required style="width:100%; padding:14px; border:1px solid #e2e8f0; border-radius:12px; font-size:15px; background:#f8fafc;"></div>
                    <button type="submit" id="auth-btn-submit" style="width:100%; padding:14px; background:#00C3AA; color:white; border:none; border-radius:12px; cursor:pointer; font-weight:600; font-size:16px;">เข้าสู่ระบบ</button>
                </form>
                <div style="margin-top:25px; font-size:14px; color:#64748b;">
                    ยังไม่มีบัญชี? <a href="javascript:void(0)" onclick="window.toggleAuthMode()" style="color:#00C3AA; font-weight:bold; text-decoration:none;">สมัครสมาชิก</a>
                </div>
            </div>
        </div>`);
    }
    db.init();
});